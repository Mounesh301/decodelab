# COBOL-IMS Banking Application

This repository contains a comprehensive banking application example built with COBOL and IMS DB/DC for mainframe environments. The application demonstrates core banking functions including customer management, account processing, and transaction handling through a hierarchical database structure.

## Project Overview

This banking application simulates a real-world financial system with the following components:

1. **Customer Management Module (CUSTMAIN)**
   - Add, update, and delete customer records
   - View customer details
   - List all customers
   - Integrated with account creation

2. **Account Processing Module (ACCTPROC)**
   - Create checking, savings, and loan accounts
   - Update account parameters (interest rates, overdraft limits)
   - Close accounts
   - Check balances and account status
   - List customer accounts

3. **Transaction Processing Module (TRANPROC)**
   - Deposit and withdraw funds
   - Transfer between accounts
   - View transaction history
   - Transaction logging with timestamps

4. **IMS Database Integration**
   - Hierarchical database design with customer → account → transaction segments
   - DL/I calls for database operations
   - Proper status code handling
   - Data integrity enforcement

## Technical Architecture

The application uses:

- **COBOL**: Programming language for all business logic
- **IMS DB/DC**: Information Management System for hierarchical database and transaction management
- **JCL**: Job Control Language for compilation, database generation, and program execution
- **Copybooks**: Shared data structures for consistency across modules
- **DBD/PSB**: Database and Program descriptions for IMS

## Folder Structure

```
cobol-ims-banking/
├── src/
│   ├── cobol/
│   │   ├── CUSTMAIN.cbl     # Main customer module
│   │   ├── ACCTPROC.cbl     # Account processing module
│   │   └── TRANPROC.cbl     # Transaction processing module
│   ├── copybook/
│   │   ├── CUSTSTRUC.cpy    # Customer data structure
│   │   ├── ACCTSTRUC.cpy    # Account data structure
│   │   └── TRANSTRUC.cpy    # Transaction data structure
│   └── jcl/
│       ├── COMPILE.jcl      # JCL to compile all modules
│       └── RUNPROG.jcl      # JCL to run the application
├── db/
│   ├── BANKDBD.dbd          # Banking database description
│   ├── BANKPSB.psb          # Program specification block
│   └── DBDGEN.jcl           # JCL to generate DBDs
├── test/
│   └── data/
│       └── TESTDATA.dat     # Test data
└── README.md                # Project documentation
```

## Database Structure

The application uses a three-level hierarchical database:

1. **CUSTOMER** (Root Segment)
   - Contains customer identification and contact information
   - Unique key: Customer ID
   - Includes fields for name, address, contact information, status

2. **ACCOUNT** (Child of CUSTOMER)
   - Represents financial accounts owned by customers
   - Unique key: Account Number
   - Includes account type, balance, interest rates, limits, status

3. **TRANHIST** (Child of ACCOUNT)
   - Records financial transaction history
   - Unique key: Transaction ID
   - Includes transaction type, amount, date/time, descriptions

## Features

### Customer Management
- Personal and business customer support
- Complete customer profile management
- Address and contact information tracking
- Customer status monitoring (active, inactive, suspended)

### Account Management
- Multiple account types (checking, savings, loans)
- Interest rate configuration
- Overdraft limit management
- Balance tracking and reporting
- Account status lifecycle (open, dormant, closed, frozen)

### Transaction Processing
- Multiple transaction types (deposits, withdrawals, transfers)
- Automated transaction logging
- Balance validation and overdraft handling
- Fund transfers between accounts
- Detailed transaction history reporting

## Installation and Setup

1. **Upload the code**:
   - Transfer all files to your mainframe environment maintaining the folder structure
   - Ensure EBCDIC conversion for text files

2. **Compile the programs**:
   - Submit the JCL in `src/jcl/COMPILE.jcl`
   - This will compile all three COBOL programs

3. **Generate the database**:
   - Submit the JCL in `db/DBDGEN.jcl`
   - This will create the Database Descriptions, Program Specification Blocks, and initialize the database

4. **Load test data** (optional):
   - Use the data in `test/data/TESTDATA.dat` as a reference
   - Create a custom JCL to load this data or enter it manually through the application

5. **Run the application**:
   - Submit the JCL in `src/jcl/RUNPROG.jcl`
   - This will execute the main CUSTMAIN program

## Usage Examples

### Adding a New Customer
1. Start CUSTMAIN program
2. Select option 'A' for Add New Customer
3. Enter customer information when prompted
4. Customer will be added to the database
5. Option to create accounts for the new customer

### Processing a Deposit
1. Start TRANPROC program
2. Select option 'D' for Deposit Funds
3. Enter account number
4. Enter deposit amount
5. System will update account balance and record the transaction

### Viewing Transaction History
1. Start TRANPROC program
2. Select option 'H' for View Transaction History
3. Enter account number
4. System will display all transactions for the account in chronological order

## Customization

The application can be customized for specific banking requirements:

- Modify the database structure in BANKDBD.dbd
- Add new fields to the copybooks
- Extend the COBOL programs with additional business logic
- Create new JCL procedures for automated processes

## Limitations and Considerations

- The application is designed for educational and demonstration purposes
- Production deployments would require additional security features
- Error handling could be enhanced for production use
- Backup and recovery procedures should be implemented
- Performance optimization may be needed for large-scale deployment

## Contributing

Feel free to fork this repository and enhance the application with:

- Additional banking features
- Improved error handling
- Performance optimizations
- Extended reporting capabilities
- User interface improvements

## License

This project is available for educational and demonstration purposes.

## Author

Banking System Development Team
